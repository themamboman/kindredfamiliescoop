"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createUserWithEmailAndPassword, onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase";

export default function AdminRegisterPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [authorized, setAuthorized] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        console.log("No user, redirecting to login");
        // Small timeout helps prevent redirect loops in Chrome
        setTimeout(() => router.push("/admin/login"), 50);
        return;
      }
      
      console.log("User authorized:", user.email);
      setAuthorized(true);
      setLoading(false);
    });

    return () => {
      console.log("Cleaning up auth listener");
      unsubscribe();
    };
  }, [router]);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setMessage("");

    try {
      await createUserWithEmailAndPassword(auth, email, password);
      setMessage("Registration successful. Redirecting...");
      // Added slight delay for better UX
      setTimeout(() => router.push("/admin/applications"), 1000);
    } catch (err: any) {
      console.error("Registration error:", err);
      setError(err.message || "Registration failed");
    }
  };

  if (loading || !authorized) {
    return (
      <main className="min-h-screen flex items-center justify-center text-gray-600">
        <div className="text-center">
          <p>Checking authorization...</p>
          {!authorized && <p className="mt-2 text-sm">Redirecting to login...</p>}
        </div>
      </main>
    );
  }

  return (
    <main className="max-w-md mx-auto py-20 px-4">
      <h2 className="text-2xl font-semibold mb-6 text-center">Admin Registration</h2>
      <form onSubmit={handleRegister} className="space-y-4">
        <input
          type="email"
          placeholder="Email"
          className="w-full px-3 py-2 border rounded"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Password"
          className="w-full px-3 py-2 border rounded"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 disabled:opacity-50"
          disabled={loading}
        >
          {loading ? "Processing..." : "Register"}
        </button>
      </form>
      {error && (
        <p className="mt-4 text-red-600 text-sm text-center">
          {error.replace("Firebase: ", "")}
        </p>
      )}
      {message && (
        <p className="mt-4 text-green-600 text-sm text-center">{message}</p>
      )}
    </main>
  );
}