// src/app/apply/page.tsx
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { db } from "@/lib/firebase";
import { collection, addDoc, Timestamp } from "firebase/firestore";

export default function ApplyPage() {
  const router = useRouter();

  const [parentNames, setParentNames] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [emergencyContact, setEmergencyContact] = useState("");
  const [maritalStatus, setMaritalStatus] = useState("");
  const [currentlyHomeschooling, setCurrentlyHomeschooling] = useState("");
  const [homeschoolingDuration, setHomeschoolingDuration] = useState("");
  const [otherCoops, setOtherCoops] = useState("");
  const [coopExperience, setCoopExperience] = useState("");
  const [reasons, setReasons] = useState("");
  const [church, setChurch] = useState("");
  const [referralSource, setReferralSource] = useState("");
  const [parentFaith, setParentFaith] = useState("");
  const [spouseFaith, setSpouseFaith] = useState("");
  const [statementAgreement, setStatementAgreement] = useState(false);
  const [communityStandards, setCommunityStandards] = useState(false);
  const [volunteerWilling, setVolunteerWilling] = useState(false);
  const [volunteerAreas, setVolunteerAreas] = useState("");
  const [skills, setSkills] = useState("");
  const [scheduling, setScheduling] = useState("");
  const [commitment, setCommitment] = useState("");
  const [photoConsent, setPhotoConsent] = useState(false);
  const [otherInfo, setOtherInfo] = useState("");
  const [children, setChildren] = useState([{ name: "", age: "", grade: "" }]);

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage("");
    setError("");

    try {
      await addDoc(collection(db, "applications"), {
        parentNames,
        phone,
        email,
        address,
        emergencyContact,
        maritalStatus,
        currentlyHomeschooling,
        homeschoolingDuration,
        otherCoops,
        coopExperience,
        reasons,
        church,
        referralSource,
        parentFaith,
        spouseFaith,
        statementAgreement,
        communityStandards,
        volunteerWilling,
        volunteerAreas,
        skills,
        scheduling,
        commitment,
        photoConsent,
        otherInfo,
        children,
        submittedAt: Timestamp.now(),
      });
      setMessage("Application submitted successfully!");
    } catch (err: any) {
      setError(err.message || "Submission failed");
    }
  };

  return (
 <main className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
  <div className="max-w-4xl mx-auto bg-white shadow-lg rounded-xl p-8">
    <h1 className="text-3xl font-bold text-center mb-2 text-red-700">Family Application Form</h1>
    <p className="text-center text-gray-600 mb-8">Please complete the form to apply for participation in the Kindred Families Homeschool Co-op.</p>

    <form onSubmit={handleSubmit} className="space-y-6">
      {/* SECTION 1: Family Info */}
      <h2 className="section-title">Family Information</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input type="text" placeholder="Parent/Guardian Name(s)" className="input" value={parentNames} onChange={(e) => setParentNames(e.target.value)} />
        <input type="text" placeholder="Phone Number" className="input" value={phone} onChange={(e) => setPhone(e.target.value)} />
        <input type="email" placeholder="Email Address" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input type="text" placeholder="Home Address" className="input" value={address} onChange={(e) => setAddress(e.target.value)} />
        <input type="text" placeholder="Emergency Contact (name, relationship, phone)" className="input col-span-2" value={emergencyContact} onChange={(e) => setEmergencyContact(e.target.value)} />
      </div>

      {/* SECTION 2: Family Details */}
      <h2 className="section-title">Family Details</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input type="text" placeholder="Marital Status" className="input" value={maritalStatus} onChange={(e) => setMaritalStatus(e.target.value)} />
        <input type="text" placeholder="Are you currently homeschooling?" className="input" value={currentlyHomeschooling} onChange={(e) => setCurrentlyHomeschooling(e.target.value)} />
        <input type="text" placeholder="How long have you been homeschooling?" className="input" value={homeschoolingDuration} onChange={(e) => setHomeschoolingDuration(e.target.value)} />
        <input type="text" placeholder="Have you been part of other homeschool co-ops?" className="input" value={otherCoops} onChange={(e) => setOtherCoops(e.target.value)} />
      </div>
      <textarea placeholder="Experience with other co-ops" className="input w-full" value={coopExperience} onChange={(e) => setCoopExperience(e.target.value)} />
      <textarea placeholder="Reasons for homeschooling" className="input w-full" value={reasons} onChange={(e) => setReasons(e.target.value)} />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input type="text" placeholder="Church you currently attend" className="input" value={church} onChange={(e) => setChurch(e.target.value)} />
        <input type="text" placeholder="How did you hear about Kindred Families?" className="input" value={referralSource} onChange={(e) => setReferralSource(e.target.value)} />
      </div>

      {/* SECTION 3: Children */}
      <h2 className="section-title">Children’s Information</h2>
      <p className="subtext">(Repeat this section for each child)</p>
      {children.map((child, index) => (
        <div key={index} className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <input type="text" placeholder="Child's Full Name" className="input" value={child.name} onChange={(e) => {
            const updated = [...children];
            updated[index].name = e.target.value;
            setChildren(updated);
          }} />
          <input type="text" placeholder="Age" className="input" value={child.age} onChange={(e) => {
            const updated = [...children];
            updated[index].age = e.target.value;
            setChildren(updated);
          }} />
          <input type="text" placeholder="Grade" className="input" value={child.grade} onChange={(e) => {
            const updated = [...children];
            updated[index].grade = e.target.value;
            setChildren(updated);
          }} />
        </div>
      ))}
      <button
        type="button"
        onClick={() => setChildren([...children, { name: "", age: "", grade: "" }])}
        className="text-blue-600 hover:underline text-sm"
      >
        + Add another child
      </button>

      {/* SUBMIT */}
      <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 mt-6">
        Submit Application
      </button>
      {message && <p className="text-green-600 text-center mt-4">{message}</p>}
      {error && <p className="text-red-600 text-center mt-4">{error}</p>}
    </form>
  </div>
</main>
);

}
