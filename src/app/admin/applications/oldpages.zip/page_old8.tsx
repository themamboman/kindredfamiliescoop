// src/app/admin/applications/page.tsx
"use client";

import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import {
  collection,
  getDocs,
  updateDoc,
  doc,
  Timestamp,
} from "firebase/firestore";

interface Application {
  id: string;
  parentNames: string;
  phone: string;
  email: string;
  address: string;
  emergencyContact: string;
  maritalStatus: string;
  currentlyHomeschooling: string;
  homeschoolingDuration: string;
  otherCoops: string;
  coopExperience: string;
  reasons: string;
  church: string;
  referralSource: string;
  parentFaith: string;
  spouseFaith: string;
  statementAgreement: boolean;
  communityStandards: boolean;
  volunteerWilling: boolean;
  volunteerAreas: string;
  skills: string;
  scheduling: string;
  commitment: string;
  photoConsent: boolean;
  otherInfo: string;
  children: { name: string; age: string; grade: string }[];
  submittedAt: any;
  seen?: boolean;
  seenBy?: string;
  seenAt?: Timestamp;
  approved?: boolean;
  approvedBy?: string;
  approvedAt?: Timestamp;
  invited?: boolean;
  invitedBy?: string;
  invitedAt?: Timestamp;
  demo?: boolean;
}

export default function AdminApplicationsPage() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const currentUserEmail = typeof window !== "undefined" ? localStorage.getItem("adminEmail") || "admin" : "admin";

  useEffect(() => {
    const fetchApplications = async () => {
      const querySnapshot = await getDocs(collection(db, "applications"));
      const apps: Application[] = [];
      querySnapshot.forEach((docSnap) => {
        const data = docSnap.data() as Application;
        if (!data.demo) {
          apps.push({ id: docSnap.id, ...data });
        }
      });
      setApplications(apps);
    };
    fetchApplications();
  }, []);

  const toggleExpanded = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  const closeExpanded = () => {
    setExpandedId(null);
  };

  const updateStatus = async (id: string, field: "seen" | "approved" | "invited", value: boolean) => {
    const docRef = doc(db, "applications", id);
    const timestamp = Timestamp.now();
    const updateData: any = { [field]: value };
    if (field === "seen") {
      updateData.seenBy = currentUserEmail;
      updateData.seenAt = timestamp;
    } else if (field === "approved") {
      updateData.approvedBy = currentUserEmail;
      updateData.approvedAt = timestamp;
    } else if (field === "invited") {
      updateData.invitedBy = currentUserEmail;
      updateData.invitedAt = timestamp;
    }
    await updateDoc(docRef, updateData);
    setApplications((prev) =>
      prev.map((app) =>
        app.id === id ? { ...app, ...updateData } : app
      )
    );
  };

  const sendEnrollmentEmail = async (app: Application) => {
    const subject = encodeURIComponent("You're Approved - Next Steps for Enrollment");
    const body = encodeURIComponent(`Thank you for filling out the application to join Kindred Families.

Congratulations! Your application has been approved.

Please visit the following secure link to complete your enrollment:

https://yourdomain.com/enroll?token=UNIQUE_TOKEN

Thank you,\nKindred Families`);
    window.location.href = `mailto:${app.email}?subject=${subject}&body=${body}`;
    await updateStatus(app.id, "invited", true);
  };

   const toggleSection = (section: string) => {
    setCollapsedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  return (
    <main className="max-w-6xl mx-auto py-10 px-4 sm:px-6">
      <h1 className="text-3xl font-bold text-center text-gray-900 mb-8 font-serif">
        Submitted Applications
      </h1>
      
      {/* Table remains the same ... */}

      {/* Application Detail Popup */}
      {applications.map((app) =>
        expandedId === app.id && (
          <div key={app.id} className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="relative bg-white w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-lg shadow-xl p-6">
              <button
                onClick={closeExpanded}
                className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
              </button>

              <div className="mb-6">
                <h2 className="text-2xl font-bold text-gray-800 mb-1 font-serif">
                  Application for {app.parentNames}
                </h2>
                <p className="text-sm text-gray-500">
                  Submitted on {new Date(app.submittedAt?.toDate()).toLocaleDateString()}
                </p>
              </div>

              {/* Collapsible Family Information Section */}
              <div className="mb-4 border border-gray-200 rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleSection('familyInfo')}
                  className="w-full flex justify-between items-center p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <h3 className="text-lg font-semibold text-gray-800">Family Information</h3>
                  {collapsedSections['familyInfo'] ? <ChevronRight className="text-gray-500" /> : <ChevronDown className="text-gray-500" />}
                </button>
                {!collapsedSections['familyInfo'] && (
                  <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div>
                        <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Parent/Guardian Names</p>
                        <p className="text-gray-800">{app.parentNames}</p>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Phone Number</p>
                        <p className="text-gray-800">{app.phone}</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Email Address</p>
                        <p className="text-gray-800">{app.email}</p>
                      </div>
                      <div>
                        <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Home Address</p>
                        <p className="text-gray-800">{app.address}</p>
                      </div>
                    </div>
                    <div className="md:col-span-2">
                      <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Emergency Contact</p>
                      <p className="text-gray-800">{app.emergencyContact}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Collapsible Family Details Section */}
              <div className="mb-4 border border-gray-200 rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleSection('familyDetails')}
                  className="w-full flex justify-between items-center p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <h3 className="text-lg font-semibold text-gray-800">Family Details</h3>
                  {collapsedSections['familyDetails'] ? <ChevronRight className="text-gray-500" /> : <ChevronDown className="text-gray-500" />}
                </button>
                {!collapsedSections['familyDetails'] && (
                  <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* ... similar structure for family details ... */}
                  </div>
                )}
              </div>

              {/* Children's Information Section */}
              <div className="mb-4 border border-gray-200 rounded-lg overflow-hidden">
                <button
                  onClick={() => toggleSection('childrenInfo')}
                  className="w-full flex justify-between items-center p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <h3 className="text-lg font-semibold text-gray-800">Children's Information</h3>
                  {collapsedSections['childrenInfo'] ? <ChevronRight className="text-gray-500" /> : <ChevronDown className="text-gray-500" />}
                </button>
                {!collapsedSections['childrenInfo'] && (
                  <div className="p-4 space-y-4">
                    {app.children.map((child, idx) => (
                      <div key={idx} className="border-b border-gray-100 pb-4 last:border-b-0">
                        <h4 className="font-medium text-gray-800 mb-2">Child #{idx + 1}</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Full Name</p>
                            <p className="text-gray-800">{child.name}</p>
                          </div>
                          <div>
                            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Age</p>
                            <p className="text-gray-800">{child.age}</p>
                          </div>
                          <div>
                            <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Grade Level</p>
                            <p className="text-gray-800">{child.grade}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* ... similar collapsible sections for Faith & Agreement, Co-op Participation, Final Questions ... */}

              {/* Action Buttons */}
              <div className="flex justify-between items-center mt-6 pt-4 border-t border-gray-200">
                <div className="flex space-x-3">
                  <button 
                    onClick={() => updateStatus(app.id, "seen", true)}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md shadow-sm transition-colors flex items-center space-x-2"
                  >
                    <span>Mark Seen</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </button>
                  <button 
                    onClick={() => updateStatus(app.id, "approved", true)}
                    className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md shadow-sm transition-colors flex items-center space-x-2"
                  >
                    <span>Mark Approved</span>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                  </button>
                </div>
                <button 
                  onClick={closeExpanded}
                  className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-md shadow-sm transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )
      )}
    </main>
  );
}