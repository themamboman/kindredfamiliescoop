// src/app/admin/applications/page.tsx
"use client";

import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import {
  collection,
  getDocs,
  updateDoc,
  doc,
  Timestamp,
} from "firebase/firestore";

interface Application {
  id: string;
  parentNames: string;
  phone: string;
  email: string;
  address: string;
  emergencyContact: string;
  maritalStatus: string;
  currentlyHomeschooling: string;
  homeschoolingDuration: string;
  otherCoops: string;
  coopExperience: string;
  reasons: string;
  church: string;
  referralSource: string;
  parentFaith: string;
  spouseFaith: string;
  statementAgreement: boolean;
  communityStandards: boolean;
  volunteerWilling: boolean;
  volunteerAreas: string;
  skills: string;
  scheduling: string;
  commitment: string;
  photoConsent: boolean;
  otherInfo: string;
  children: { name: string; age: string; grade: string }[];
  submittedAt: any;
  seen?: boolean;
  seenBy?: string;
  seenAt?: Timestamp;
  approved?: boolean;
  approvedBy?: string;
  approvedAt?: Timestamp;
  invited?: boolean;
  invitedBy?: string;
  invitedAt?: Timestamp;
  demo?: boolean;
}

export default function AdminApplicationsPage() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
  const currentUserEmail = typeof window !== "undefined" ? localStorage.getItem("adminEmail") || "admin" : "admin";

  useEffect(() => {
    const fetchApplications = async () => {
      const querySnapshot = await getDocs(collection(db, "applications"));
      const apps: Application[] = [];
      querySnapshot.forEach((docSnap) => {
        const data = docSnap.data() as Application;
        if (!data.demo) {
          apps.push({ id: docSnap.id, ...data });
        }
      });
      setApplications(apps);
    };
    fetchApplications();
  }, []);

  const toggleExpanded = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  const closeExpanded = () => {
    setExpandedId(null);
  };

  const toggleSection = (sectionKey: string) => {
    setCollapsedSections((prev) => ({
      ...prev,
      [sectionKey]: !prev[sectionKey],
    }));
  };

  const updateStatus = async (id: string, field: "seen" | "approved" | "invited", value: boolean) => {
    const docRef = doc(db, "applications", id);
    const timestamp = Timestamp.now();
    const updateData: any = { [field]: value };
    if (field === "seen") {
      updateData.seenBy = currentUserEmail;
      updateData.seenAt = timestamp;
    } else if (field === "approved") {
      updateData.approvedBy = currentUserEmail;
      updateData.approvedAt = timestamp;
    } else if (field === "invited") {
      updateData.invitedBy = currentUserEmail;
      updateData.invitedAt = timestamp;
    }
    await updateDoc(docRef, updateData);
    setApplications((prev) => prev.map((app) => (app.id === id ? { ...app, ...updateData } : app)));
  };

  const sendEnrollmentEmail = async (app: Application) => {
    const subject = encodeURIComponent("You're Approved - Next Steps for Enrollment");
    const body = encodeURIComponent(`Thank you for filling out the application to join Kindred Families.

Congratulations! Your application has been approved.

Please visit the following secure link to complete your enrollment:

https://yourdomain.com/enroll?token=UNIQUE_TOKEN

Thank you,\nKindred Families`);
    window.location.href = `mailto:${app.email}?subject=${subject}&body=${body}`;
    updateStatus(app.id, "invited", true);
  };

  return (
    <main className="max-w-6xl mx-auto py-10 px-6">
      <h1 className="text-3xl font-bold text-center text-red-800 mb-8">
        Submitted Applications
      </h1>

      {applications.map((app) => (
        <div key={app.id} className="border rounded-lg mb-6 bg-white shadow">
          <div className="p-4 flex justify-between items-center">
            <div>
              <h2 className="text-lg font-semibold">{app.parentNames}</h2>
              <p className="text-sm text-gray-600">{app.email}</p>
            </div>
            <div className="space-x-2">
              <button onClick={() => updateStatus(app.id, "seen", true)} className="text-sm bg-gray-200 px-3 py-1 rounded hover:bg-gray-300">
                Mark Seen
              </button>
              <button onClick={() => updateStatus(app.id, "approved", true)} className="text-sm bg-green-200 px-3 py-1 rounded hover:bg-green-300">
                Mark Approved
              </button>
              {app.approved && (
                <button onClick={() => sendEnrollmentEmail(app)} className="text-sm bg-blue-200 px-3 py-1 rounded hover:bg-blue-300">
                  Enroll Invite
                </button>
              )}
              <button onClick={() => toggleExpanded(app.id)} className="text-sm text-blue-600 underline">
                {expandedId === app.id ? "Hide" : "View"}
              </button>
            </div>
          </div>

          {expandedId === app.id && (
            <div className="px-4 pb-4">
              {renderCollapsibleSection("Family Information", `family-${app.id}`, (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p><strong>Phone:</strong> {app.phone}</p>
                    <p><strong>Address:</strong> {app.address}</p>
                    <p><strong>Emergency Contact:</strong> {app.emergencyContact}</p>
                    <p><strong>Marital Status:</strong> {app.maritalStatus}</p>
                    <p><strong>Email:</strong> {app.email}</p>
                  </div>
                </div>
              ))}

              {renderCollapsibleSection("Children", `children-${app.id}`, (
                <div className="space-y-2">
                  {app.children.map((child, idx) => (
                    <div key={idx} className="border p-2 rounded">
                      <p><strong>Name:</strong> {child.name}</p>
                      <p><strong>Age:</strong> {child.age}</p>
                      <p><strong>Grade:</strong> {child.grade}</p>
                    </div>
                  ))}
                </div>
              ))}

              {renderCollapsibleSection("Faith & Agreement", `faith-${app.id}`, (
                <div>
                  <p><strong>Parent Faith:</strong> {app.parentFaith}</p>
                  <p><strong>Spouse Faith:</strong> {app.spouseFaith}</p>
                  <p><strong>Statement Agreement:</strong> {app.statementAgreement ? "Yes" : "No"}</p>
                  <p><strong>Community Standards:</strong> {app.communityStandards ? "Yes" : "No"}</p>
                </div>
              ))}

              {renderCollapsibleSection("Co-op Participation", `coop-${app.id}`, (
                <div>
                  <p><strong>Willing to Volunteer:</strong> {app.volunteerWilling ? "Yes" : "No"}</p>
                  <p><strong>Volunteer Areas:</strong> {app.volunteerAreas}</p>
                  <p><strong>Skills:</strong> {app.skills}</p>
                  <p><strong>Scheduling:</strong> {app.scheduling}</p>
                </div>
              ))}

              {renderCollapsibleSection("Other Information", `other-${app.id}`, (
                <div>
                  <p><strong>Commitment:</strong> {app.commitment}</p>
                  <p><strong>Photo Consent:</strong> {app.photoConsent ? "Yes" : "No"}</p>
                  <p><strong>Other Info:</strong> {app.otherInfo}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
    </main>
  );

  function renderCollapsibleSection(title: string, key: string, content: JSX.Element) {
    return (
      <div className="mb-4">
        <button
          onClick={() => toggleSection(key)}
          className="w-full text-left font-semibold py-2 px-4 bg-gray-100 rounded-t"
        >
          {collapsedSections[key] ? "+" : "-"} {title}
        </button>
        {!collapsedSections[key] && (
          <div className="border-t px-4 py-2 bg-gray-50 rounded-b">
            {content}
          </div>
        )}
      </div>
    );
  }
}
