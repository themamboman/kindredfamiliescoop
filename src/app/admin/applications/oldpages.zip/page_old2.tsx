// --- Applications Dashboard ---
// src/app/admin/applications/page.tsx
"use client";

import { useEffect, useState } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

export default function AdminApplicationsPage() {
  const supabase = createClientComponentClient();
  const [applications, setApplications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedApp, setSelectedApp] = useState<any | null>(null);
  const [collapsedKeys, setCollapsedKeys] = useState<Record<string, boolean>>({});

  const fetchApplications = async () => {
    setLoading(true);
    const { data, error } = await supabase.from("applications").select("*").order("submitted_at", { ascending: false });
    if (!error) setApplications(data || []);
    setLoading(false);
  };

  const updateStatus = async (id: string, field: "seen" | "approved", value: boolean) => {
    await supabase.from("applications").update({ [field]: value }).eq("id", id);
    fetchApplications();
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const renderField = (label: string, value: any, prefix = "") => {
    const key = `${prefix}${label}`;

    if (Array.isArray(value)) {
      const isCollapsed = collapsedKeys[key] ?? true;
      return (
        <div key={key} className="py-2 border-b">
          <button onClick={() => setCollapsedKeys(prev => ({ ...prev, [key]: !isCollapsed }))} className="font-semibold text-brand">
            {isCollapsed ? "▶" : "▼"} {label} ({value.length})
          </button>
          {!isCollapsed && (
            <div className="pl-4 space-y-2 mt-2">
              {value.map((item, idx) => (
                <div key={`${key}-${idx}`} className="p-2 border rounded bg-gray-50">
                  {Object.entries(item).map(([subKey, subValue]) => renderField(subKey, subValue, `${key}-${idx}-`))}
                </div>
              ))}
            </div>
          )}
        </div>
      );
    }

    if (typeof value === 'object' && value !== null) {
      const isCollapsed = collapsedKeys[key] ?? true;
      return (
        <div key={key} className="py-2 border-b">
          <button onClick={() => setCollapsedKeys(prev => ({ ...prev, [key]: !isCollapsed }))} className="font-semibold text-brand">
            {isCollapsed ? "▶" : "▼"} {label}
          </button>
          {!isCollapsed && (
            <div className="pl-4 space-y-1 mt-2">
              {Object.entries(value).map(([subKey, subValue]) => renderField(subKey, subValue, `${key}-`))}
            </div>
          )}
        </div>
      );
    }

    return (
      <div key={key} className="flex justify-between items-start py-1 border-b">
        <span className="font-semibold text-gray-700 w-1/3 pr-2 whitespace-nowrap">{label}</span>
        <span className="w-2/3 bg-gray-100 p-2 rounded break-words text-sm">{value}</span>
      </div>
    );
  };

  return (
    <main className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Admin: Applications</h1>
      {loading ? <p>Loading...</p> : (
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100 text-left">
              <th className="p-2">Parent(s)</th>
              <th className="p-2">Submitted</th>
              <th className="p-2">Seen</th>
              <th className="p-2">Approved</th>
              <th className="p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {applications.map((app) => (
              <tr key={app.id} className="border-t">
                <td className="p-2">{app.parent_names}</td>
                <td className="p-2">{new Date(app.submitted_at).toLocaleString()}</td>
                <td className="p-2">{app.seen ? "✅" : "❌"}</td>
                <td className="p-2">{app.approved ? "✅" : "❌"}</td>
                <td className="p-2 space-x-2">
                  <button onClick={() => updateStatus(app.id, "seen", !app.seen)} className="px-2 py-1 text-sm border rounded">
                    Toggle Seen
                  </button>
                  <button onClick={() => setSelectedApp(app)} className="px-2 py-1 text-sm border rounded bg-blue-600 text-white">
                    View
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {selectedApp && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg max-w-3xl w-full shadow-lg overflow-y-auto max-h-[90vh]">
            <h2 className="text-xl font-bold mb-4">Application Details</h2>
            <div className="space-y-2">
              {Object.entries(selectedApp).map(([key, value]) => renderField(key, value))}
            </div>
            <div className="flex justify-between mt-6">
              <button onClick={() => updateStatus(selectedApp.id, "approved", !selectedApp.approved)} className="px-4 py-2 text-sm bg-green-600 text-white rounded hover:bg-green-700">
                {selectedApp.approved ? "Unapprove" : "Approve"}
              </button>
              <button onClick={() => setSelectedApp(null)} className="px-4 py-2 text-sm bg-gray-300 rounded hover:bg-gray-400">
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
