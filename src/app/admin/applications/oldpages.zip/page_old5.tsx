// src/app/admin/applications/page.tsx
"use client";

import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import {
  collection,
  getDocs,
  doc,
  updateDoc,
  query,
  orderBy,
} from "firebase/firestore";

interface Application {
  id: string;
  parentNames: string;
  phone: string;
  email: string;
  address: string;
  emergencyContact: string;
  maritalStatus: string;
  currentlyHomeschooling: string;
  homeschoolingDuration: string;
  otherCoops: string;
  coopExperience: string;
  reasons: string;
  church: string;
  referralSource: string;
  parentFaith: string;
  spouseFaith: string;
  statementAgreement: boolean;
  communityStandards: boolean;
  volunteerWilling: boolean;
  volunteerAreas: string;
  skills: string;
  scheduling: string;
  commitment: string;
  photoConsent: boolean;
  otherInfo: string;
  children: { name: string; age: string; grade: string }[];
  submittedAt: any;
  seen?: boolean;
  approved?: boolean;
}

export default function AdminApplicationsPage() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    const fetchApplications = async () => {
      const q = query(collection(db, "applications"), orderBy("submittedAt", "desc"));
      const snapshot = await getDocs(q);
      const apps = snapshot.docs.map((docSnap) => ({ id: docSnap.id, ...docSnap.data() } as Application));
      setApplications(apps);
    };
    fetchApplications();
  }, []);

  const toggleExpand = (id: string) => {
    setExpanded(expanded === id ? null : id);
  };

  const markSeen = async (id: string) => {
    const ref = doc(db, "applications", id);
    await updateDoc(ref, { seen: true });
    setApplications((prev) =>
      prev.map((app) => (app.id === id ? { ...app, seen: true } : app))
    );
  };

  const markApproved = async (id: string) => {
    const ref = doc(db, "applications", id);
    await updateDoc(ref, { approved: true });
    setApplications((prev) =>
      prev.map((app) => (app.id === id ? { ...app, approved: true } : app))
    );
  };

  return (
    <main className="max-w-5xl mx-auto py-10 px-6">
      <h1 className="text-3xl font-bold text-center mb-8">Submitted Applications</h1>
      {applications.map((app) => (
        <div
          key={app.id}
          className={`border rounded shadow mb-6 transition-all duration-300 ${
            expanded === app.id ? "bg-white" : "bg-gray-50"
          }`}
        >
          <button
            onClick={() => toggleExpand(app.id)}
            className="w-full text-left px-4 py-3 bg-red-100 hover:bg-red-200 font-semibold"
          >
            {app.parentNames} ({app.email}) - {new Date(app.submittedAt?.seconds * 1000).toLocaleString()}
          </button>
          {expanded === app.id && (
            <div className="px-4 py-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <p><strong>Phone:</strong> {app.phone}</p>
                <p><strong>Address:</strong> {app.address}</p>
                <p><strong>Emergency Contact:</strong> {app.emergencyContact}</p>
                <p><strong>Marital Status:</strong> {app.maritalStatus}</p>
                <p><strong>Currently Homeschooling:</strong> {app.currentlyHomeschooling}</p>
                <p><strong>Homeschooling Duration:</strong> {app.homeschoolingDuration}</p>
                <p><strong>Other Coops:</strong> {app.otherCoops}</p>
                <p><strong>Coop Experience:</strong> {app.coopExperience}</p>
                <p><strong>Reasons for Joining:</strong> {app.reasons}</p>
                <p><strong>Church:</strong> {app.church}</p>
                <p><strong>Referral Source:</strong> {app.referralSource}</p>
                <p><strong>Parent Faith:</strong> {app.parentFaith}</p>
                <p><strong>Spouse Faith:</strong> {app.spouseFaith}</p>
                <p><strong>Volunteer Areas:</strong> {app.volunteerAreas}</p>
                <p><strong>Skills:</strong> {app.skills}</p>
                <p><strong>Scheduling Notes:</strong> {app.scheduling}</p>
                <p><strong>Commitment:</strong> {app.commitment}</p>
                <p><strong>Other Info:</strong> {app.otherInfo}</p>
              </div>
              <div className="mt-4">
                <h3 className="font-semibold text-lg">Children</h3>
                <ul className="list-disc list-inside">
                  {app.children.map((child, idx) => (
                    <li key={idx}>{child.name} (DOB: {child.age}, Grade: {child.grade})</li>
                  ))}
                </ul>
              </div>
              <div className="mt-4 space-x-4">
                {!app.seen && (
                  <button
                    className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded"
                    onClick={() => markSeen(app.id)}
                  >
                    Mark as Seen
                  </button>
                )}
                {!app.approved && (
                  <button
                    className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded"
                    onClick={() => markApproved(app.id)}
                  >
                    Approve
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      ))}
    </main>
  );
}
