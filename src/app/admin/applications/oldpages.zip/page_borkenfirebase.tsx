// src/app/admin/applications/page.tsx
"use client";

import { useEffect, useState } from "react";
import { db } from "@/lib/firebase";
import {
  collection,
  getDocs,
  updateDoc,
  doc,
  Timestamp,
} from "firebase/firestore";

interface Application {
  id: string;
  parentNames: string;
  phone: string;
  email: string;
  address: string;
  emergencyContact: string;
  maritalStatus: string;
  currentlyHomeschooling: string;
  homeschoolingDuration: string;
  otherCoops: string;
  coopExperience: string;
  reasons: string;
  church: string;
  referralSource: string;
  parentFaith: string;
  spouseFaith: string;
  statementAgreement: boolean;
  communityStandards: boolean;
  volunteerWilling: boolean;
  volunteerAreas: string;
  skills: string;
  scheduling: string;
  commitment: string;
  photoConsent: boolean;
  otherInfo: string;
  children: { name: string; age: string; grade: string }[];
  submittedAt: any;
  seen?: boolean;
  seenBy?: string;
  seenAt?: Timestamp;
  approved?: boolean;
  approvedBy?: string;
  approvedAt?: Timestamp;
  invited?: boolean;
  invitedBy?: string;
  invitedAt?: Timestamp;
  demo?: boolean;
}

export default function AdminApplicationsPage() {
  const [applications, setApplications] = useState<Application[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [collapsedSections, setCollapsedSections] = useState<Record<string, boolean>>({});
  const currentUserEmail = typeof window !== "undefined" ? localStorage.getItem("adminEmail") || "admin" : "admin";

  useEffect(() => {
    const fetchApplications = async () => {
      const querySnapshot = await getDocs(collection(db, "applications"));
      const apps: Application[] = [];
      querySnapshot.forEach((docSnap) => {
        const data = docSnap.data() as Application;
        if (!data.demo) {
          apps.push({ id: docSnap.id, ...data });
        }
      });
      setApplications(apps);
    };
    fetchApplications();
  }, []);

  const toggleExpanded = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  const closeExpanded = () => {
    setExpandedId(null);
  };

  const toggleSection = (section: string) => {
    setCollapsedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }));
  };

  const updateStatus = async (id: string, field: "seen" | "approved" | "invited", value: boolean) => {
    const docRef = doc(db, "applications", id);
    const timestamp = Timestamp.now();
    const updateData: any = { [field]: value };
    if (field === "seen") {
      updateData.seenBy = currentUserEmail;
      updateData.seenAt = timestamp;
    } else if (field === "approved") {
      updateData.approvedBy = currentUserEmail;
      updateData.approvedAt = timestamp;
    } else if (field === "invited") {
      updateData.invitedBy = currentUserEmail;
      updateData.invitedAt = timestamp;
    }
    await updateDoc(docRef, updateData);
    setApplications((prev) =>
      prev.map((app) =>
        app.id === id ? { ...app, ...updateData } : app
      )
    );
  };

  const sendEnrollmentEmail = async (app: Application) => {
    const subject = encodeURIComponent("You're Approved - Next Steps for Enrollment");
    const body = encodeURIComponent(`Thank you for filling out the application to join Kindred Families.

Congratulations! Your application has been approved.

Please visit the following secure link to complete your enrollment:

https://yourdomain.com/enroll?token=UNIQUE_TOKEN

Thank you,\nKindred Families`);
    window.location.href = `mailto:${app.email}?subject=${subject}&body=${body}`;
    updateStatus(app.id, "invited", true);
  };

  return (
    <main className="max-w-6xl mx-auto py-10 px-6">
      <h1 className="text-3xl font-bold text-center text-red-800 mb-8">
        Submitted Applications
      </h1>
      {/* ...table and popup logic remains unchanged... */}
    </main>
  );
}
