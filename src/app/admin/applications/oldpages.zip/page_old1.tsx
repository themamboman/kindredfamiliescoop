// --- Applications Dashboard ---
// src/app/admin/applications/page.tsx
"use client";

import { useEffect, useState } from "react";
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs";

export default function AdminApplicationsPage() {
  const supabase = createClientComponentClient();
  const [applications, setApplications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchApplications = async () => {
    setLoading(true);
    const { data, error } = await supabase.from("applications").select("*").order("submitted_at", { ascending: false });
    if (!error) setApplications(data || []);
    setLoading(false);
  };

  const updateStatus = async (id: string, field: "seen" | "approved", value: boolean) => {
    await supabase.from("applications").update({ [field]: value }).eq("id", id);
    fetchApplications();
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  return (
    <main className="max-w-5xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Admin: Applications</h1>
      {loading ? <p>Loading...</p> : (
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100 text-left">
              <th className="p-2">Parent(s)</th>
              <th className="p-2">Submitted</th>
              <th className="p-2">Seen</th>
              <th className="p-2">Approved</th>
              <th className="p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {applications.map((app) => (
              <tr key={app.id} className="border-t">
                <td className="p-2">{app.parent_names}</td>
                <td className="p-2">{new Date(app.submitted_at).toLocaleString()}</td>
                <td className="p-2">{app.seen ? "✅" : "❌"}</td>
                <td className="p-2">{app.approved ? "✅" : "❌"}</td>
                <td className="p-2 space-x-2">
                  <button onClick={() => updateStatus(app.id, "seen", !app.seen)} className="px-2 py-1 text-sm border rounded">
                    Toggle Seen
                  </button>
                  <button onClick={() => updateStatus(app.id, "approved", !app.approved)} className="px-2 py-1 text-sm border rounded bg-green-600 text-white">
                    {app.approved ? "Unapprove" : "Approve"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </main>
  );
}
