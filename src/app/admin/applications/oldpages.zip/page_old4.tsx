"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase";

export default function AdminApplicationsPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (!user) {
        router.push("/admin/login");
      } else {
        setAuthenticated(true);
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, [router]);

  if (loading) {
    return <main className="text-center py-20">Loading...</main>;
  }

  if (!authenticated) {
    return <main className="text-center py-20">You must be signed in to view this page.</main>;
  }

  return (
    <main className="p-6">
      <h2 className="text-2xl font-bold mb-4">Admin Applications Dashboard</h2>
      {/* Your application list goes here */}
    </main>
  );
}
